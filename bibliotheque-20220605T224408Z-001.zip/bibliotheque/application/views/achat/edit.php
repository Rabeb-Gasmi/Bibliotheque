<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Modifier un achat </h3>
            </div>
			<?php echo form_open('achat/edit/'.$achat['id']); ?>
			<div class="box-body">
				<div class="row clearfix">
					<div class="col-md-6">
						<label for="users_id" class="control-label"><span class="text-danger">*</span>Utilisateur</label>
						<div class="form-group">
							<select name="users_id" class="form-control">
								<option value="">sélectinner l'utilisateur</option>
								<?php 
								foreach($all_users as $user)
								{
									$selected = ($user['id'] == $achat['users_id']) ? ' selected="selected"' : "";

									echo '<option value="'.$user['id'].'" '.$selected.'>'.$user['id'].'</option>';
								} 
								?>
							</select>
							<span class="text-danger"><?php echo form_error('users_id');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="document_id" class="control-label"><span class="text-danger">*</span>Document</label>
						<div class="form-group">
							<select name="document_id" class="form-control">
								<option value="">sélectinner le document</option>
								<?php 
								foreach($all_document as $document)
								{
									$selected = ($document['id'] == $achat['document_id']) ? ' selected="selected"' : "";

									echo '<option value="'.$document['id'].'" '.$selected.'>'.$document['id'].'</option>';
								} 
								?>
							</select>
							<span class="text-danger"><?php echo form_error('document_id');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="date" class="control-label">Date</label>
						<div class="form-group">
							<input type="text" name="date" value="<?php echo ($this->input->post('date') ? $this->input->post('date') : $achat['date']); ?>" class="has-datepicker form-control" id="date" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="prix" class="control-label">Prix</label>
						<div class="form-group">
							<input type="text" name="prix" value="<?php echo ($this->input->post('prix') ? $this->input->post('prix') : $achat['prix']); ?>" class="form-control" id="prix" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="commision" class="control-label">Commision</label>
						<div class="form-group">
							<input type="text" name="commision" value="<?php echo ($this->input->post('commision') ? $this->input->post('commision') : $achat['commision']); ?>" class="form-control" id="commision" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="net" class="control-label">Net</label>
						<div class="form-group">
							<input type="text" name="net" value="<?php echo ($this->input->post('net') ? $this->input->post('net') : $achat['net']); ?>" class="form-control" id="net" />
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Enregistrer
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>