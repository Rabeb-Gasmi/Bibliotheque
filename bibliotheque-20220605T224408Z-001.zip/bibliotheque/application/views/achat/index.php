<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Liste des achats</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('achat/add'); ?>" class="btn btn-success btn-sm">Ajouter</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>ID</th>
						<th>Users Id</th>
						<th>Document Id</th>
						<th>Date</th>
						<th>Prix</th>
						<th>Commision</th>
						<th>Net</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($achat as $a){ ?>
                    <tr>
						<td><?php echo $a['id']; ?></td>
						<td><?php echo $a['users_id']; ?></td>
						<td><?php echo $a['document_id']; ?></td>
						<td><?php echo $a['date']; ?></td>
						<td><?php echo $a['prix']; ?></td>
						<td><?php echo $a['commision']; ?></td>
						<td><?php echo $a['net']; ?></td>
						<td>
                            <a href="<?php echo site_url('achat/edit/'.$a['id']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Modifier</a> 
                            <a href="<?php echo site_url('achat/remove/'.$a['id']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Supprimer</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                <div class="pull-right">
                    <?php echo $this->pagination->create_links(); ?>                    
                </div>                
            </div>
        </div>
    </div>
</div>
