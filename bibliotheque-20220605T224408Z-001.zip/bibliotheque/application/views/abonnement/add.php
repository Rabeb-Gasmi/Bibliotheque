<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Ajouter un abonnement</h3>
            </div>
            <?php echo form_open('abonnement/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<label for="users_id" class="control-label"><span class="text-danger">*</span>Utilisateur</label>
						<div class="form-group">
							<select name="users_id" class="form-control">
								<option value="">sélectionner l'Utilisateur</option>
								<?php 
								foreach($all_users as $user)
								{
									$selected = ($user['id'] == $this->input->post('users_id')) ? ' selected="selected"' : "";

									echo '<option value="'.$user['id'].'" '.$selected.'>'.$user['id'].'</option>';
								} 
								?>
							</select>
							<span class="text-danger"><?php echo form_error('users_id');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="tarif_id" class="control-label"><span class="text-danger">*</span>Tarif</label>
						<div class="form-group">
							<select name="tarif_id" class="form-control">
								<option value="">selection tarif</option>
								<?php 
								foreach($all_tarif as $tarif)
								{
									$selected = ($tarif['id'] == $this->input->post('tarif_id')) ? ' selected="selected"' : "";

									echo '<option value="'.$tarif['id'].'" '.$selected.'>'.$tarif['id'].'</option>';
								} 
								?>
							</select>
							<span class="text-danger"><?php echo form_error('tarif_id');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="prix" class="control-label"><span class="text-danger">*</span>Prix</label>
						<div class="form-group">
							<input type="text" name="prix" value="<?php echo $this->input->post('prix'); ?>" class="form-control" id="prix" />
							<span class="text-danger"><?php echo form_error('prix');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="date_debut" class="control-label"><span class="text-danger">*</span>Date Debut</label>
						<div class="form-group">
							<input type="text" name="date_debut" value="<?php echo $this->input->post('date_debut'); ?>" class="has-datepicker form-control" id="date_debut" />
							<span class="text-danger"><?php echo form_error('date_debut');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="date_fin" class="control-label"><span class="text-danger">*</span>Date Fin</label>
						<div class="form-group">
							<input type="text" name="date_fin" value="<?php echo $this->input->post('date_fin'); ?>" class="has-datepicker form-control" id="date_fin" />
							<span class="text-danger"><?php echo form_error('date_fin');?></span>
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Enregistrer
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>