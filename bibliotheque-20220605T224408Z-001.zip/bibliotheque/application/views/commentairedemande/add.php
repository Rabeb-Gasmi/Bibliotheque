<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Ajouter un commentaire de demande</h3>
            </div>
            <?php echo form_open('commentairedemande/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<label for="users_id" class="control-label"><span class="text-danger">*</span>Utilisateur</label>
						<div class="form-group">
							<select name="users_id" class="form-control">
								<option value="">sélectionner l'utilisateur</option>
								<?php 
								foreach($all_users as $user)
								{
									$selected = ($user['id'] == $this->input->post('users_id')) ? ' selected="selected"' : "";

									echo '<option value="'.$user['id'].'" '.$selected.'>'.$user['id'].'</option>';
								} 
								?>
							</select>
							<span class="text-danger"><?php echo form_error('users_id');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="document_id" class="control-label"><span class="text-danger">*</span>Document</label>
						<div class="form-group">
							<select name="document_id" class="form-control">
								<option value="">sélectionner le document</option>
								<?php 
								foreach($all_document as $document)
								{
									$selected = ($document['id'] == $this->input->post('document_id')) ? ' selected="selected"' : "";

									echo '<option value="'.$document['id'].'" '.$selected.'>'.$document['id'].'</option>';
								} 
								?>
							</select>
							<span class="text-danger"><?php echo form_error('document_id');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="texte" class="control-label">Texte</label>
						<div class="form-group">
							<input type="text" name="texte" value="<?php echo $this->input->post('texte'); ?>" class="form-control" id="texte" />
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Enregistrer
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>