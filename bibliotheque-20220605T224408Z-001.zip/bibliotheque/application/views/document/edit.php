<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Modifier un document</h3>
            </div>
			<?php echo form_open('document/edit/'.$document['id']); ?>
			<div class="box-body">
				<div class="row clearfix">
					<div class="col-md-6">
						<label for="users_id" class="control-label"><span class="text-danger">*</span>Utilisateur</label>
						<div class="form-group">
							<select name="users_id" class="form-control">
								<option value="">sélectionner l'Utilisateur</option>
								<?php 
								foreach($all_users as $user)
								{
									$selected = ($user['id'] == $document['users_id']) ? ' selected="selected"' : "";

									echo '<option value="'.$user['id'].'" '.$selected.'>'.$user['id'].'</option>';
								} 
								?>
							</select>
							<span class="text-danger"><?php echo form_error('users_id');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="theme_id" class="control-label"><span class="text-danger">*</span>Thème</label>
						<div class="form-group">
							<select name="theme_id" class="form-control">
								<option value="">sélectionner la thème</option>
								<?php 
								foreach($all_theme as $theme)
								{
									$selected = ($theme['id'] == $document['theme_id']) ? ' selected="selected"' : "";

									echo '<option value="'.$theme['id'].'" '.$selected.'>'.$theme['id'].'</option>';
								} 
								?>
							</select>
							<span class="text-danger"><?php echo form_error('theme_id');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="categorie_id" class="control-label"><span class="text-danger">*</span>Catégorie</label>
						<div class="form-group">
							<select name="categorie_id" class="form-control">
								<option value="">sélectionner la catégorie</option>
								<?php 
								foreach($all_categorie as $categorie)
								{
									$selected = ($categorie['id'] == $document['categorie_id']) ? ' selected="selected"' : "";

									echo '<option value="'.$categorie['id'].'" '.$selected.'>'.$categorie['id'].'</option>';
								} 
								?>
							</select>
							<span class="text-danger"><?php echo form_error('categorie_id');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="titre" class="control-label"><span class="text-danger">*</span>Titre</label>
						<div class="form-group">
							<input type="text" name="titre" value="<?php echo ($this->input->post('titre') ? $this->input->post('titre') : $document['titre']); ?>" class="form-control" id="titre" />
							<span class="text-danger"><?php echo form_error('titre');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="auteur" class="control-label">Auteur</label>
						<div class="form-group">
							<input type="text" name="auteur" value="<?php echo ($this->input->post('auteur') ? $this->input->post('auteur') : $document['auteur']); ?>" class="form-control" id="auteur" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="description" class="control-label">Description</label>
						<div class="form-group">
							<input type="text" name="description" value="<?php echo ($this->input->post('description') ? $this->input->post('description') : $document['description']); ?>" class="form-control" id="description" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="volume" class="control-label">Volume</label>
						<div class="form-group">
							<input type="text" name="volume" value="<?php echo ($this->input->post('volume') ? $this->input->post('volume') : $document['volume']); ?>" class="form-control" id="volume" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="annee" class="control-label">Année</label>
						<div class="form-group">
							<input type="text" name="annee" value="<?php echo ($this->input->post('annee') ? $this->input->post('annee') : $document['annee']); ?>" class="has-datepicker form-control" id="annee" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="prix" class="control-label"><span class="text-danger">*</span>Prix</label>
						<div class="form-group">
							<input type="text" name="prix" value="<?php echo ($this->input->post('prix') ? $this->input->post('prix') : $document['prix']); ?>" class="form-control" id="prix" />
							<span class="text-danger"><?php echo form_error('prix');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="created_at" class="control-label"><span class="text-danger">*</span>Crée le</label>
						<div class="form-group">
							<input type="text" name="created_at" value="<?php echo ($this->input->post('created_at') ? $this->input->post('created_at') : $document['created_at']); ?>" class="has-datepicker form-control" id="created_at" />
							<span class="text-danger"><?php echo form_error('created_at');?></span>
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Enregistrer
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>