<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Liste des documents</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('document/add'); ?>" class="btn btn-success btn-sm">Ajouter</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>ID</th>
						<th>Users Id</th>
						<th>Thème Id</th>
						<th>Catégorie Id</th>
						<th>Titre</th>
						<th>Auteur</th>
						<th>Description</th>
						<th>Volume</th>
						<th>Année</th>
						<th>Prix</th>
						<th>Crée le</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($document as $d){ ?>
                    <tr>
						<td><?php echo $d['id']; ?></td>
						<td><?php echo $d['users_id']; ?></td>
						<td><?php echo $d['theme_id']; ?></td>
						<td><?php echo $d['categorie_id']; ?></td>
						<td><?php echo $d['titre']; ?></td>
						<td><?php echo $d['auteur']; ?></td>
						<td><?php echo $d['description']; ?></td>
						<td><?php echo $d['volume']; ?></td>
						<td><?php echo $d['annee']; ?></td>
						<td><?php echo $d['prix']; ?></td>
						<td><?php echo $d['created_at']; ?></td>
						<td>
                            <a href="<?php echo site_url('document/edit/'.$d['id']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span>Modifier</a> 
                            <a href="<?php echo site_url('document/remove/'.$d['id']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Supprimer</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                <div class="pull-right">
                    <?php echo $this->pagination->create_links(); ?>                    
                </div>                
            </div>
        </div>
    </div>
</div>
