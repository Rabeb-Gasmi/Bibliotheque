<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Liste des commentaires</h3>
            	<div class="box-tools">
                    <a href="<?php echo site_url('commentaire/add'); ?>" class="btn btn-success btn-sm">Ajouter</a> 
                </div>
            </div>
            <div class="box-body">
                <table class="table table-striped">
                    <tr>
						<th>ID</th>
						<th>Document Id</th>
						<th>Users Id</th>
						<th>Texte</th>
						<th>Crée le</th>
						<th>Actions</th>
                    </tr>
                    <?php foreach($commentaire as $c){ ?>
                    <tr>
						<td><?php echo $c['id']; ?></td>
						<td><?php echo $c['document_id']; ?></td>
						<td><?php echo $c['users_id']; ?></td>
						<td><?php echo $c['texte']; ?></td>
						<td><?php echo $c['created_at']; ?></td>
						<td>
                            <a href="<?php echo site_url('commentaire/edit/'.$c['id']); ?>" class="btn btn-info btn-xs"><span class="fa fa-pencil"></span> Modifier</a> 
                            <a href="<?php echo site_url('commentaire/remove/'.$c['id']); ?>" class="btn btn-danger btn-xs"><span class="fa fa-trash"></span> Supprimer</a>
                        </td>
                    </tr>
                    <?php } ?>
                </table>
                <div class="pull-right">
                    <?php echo $this->pagination->create_links(); ?>                    
                </div>                
            </div>
        </div>
    </div>
</div>
