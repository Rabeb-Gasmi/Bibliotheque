<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Ajouter une demande_retrait</h3>
            </div>
            <?php echo form_open('demanderetrait/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<label for="users_id" class="control-label"><span class="text-danger">*</span>Utilisateur</label>
						<div class="form-group">
							<select name="users_id" class="form-control">
								<option value="">sélectionner l'utilisateur</option>
								<?php 
								foreach($all_users as $user)
								{
									$selected = ($user['id'] == $this->input->post('users_id')) ? ' selected="selected"' : "";

									echo '<option value="'.$user['id'].'" '.$selected.'>'.$user['id'].'</option>';
								} 
								?>
							</select>
							<span class="text-danger"><?php echo form_error('users_id');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="date" class="control-label"><span class="text-danger">*</span>Date</label>
						<div class="form-group">
							<input type="text" name="date" value="<?php echo $this->input->post('date'); ?>" class="has-datepicker form-control" id="date" />
							<span class="text-danger"><?php echo form_error('date');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="montant" class="control-label"><span class="text-danger">*</span>Montant</label>
						<div class="form-group">
							<input type="text" name="montant" value="<?php echo $this->input->post('montant'); ?>" class="form-control" id="montant" />
							<span class="text-danger"><?php echo form_error('montant');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="confirmed" class="control-label"><span class="text-danger">*</span>Confirmé</label>
						<div class="form-group">
							<input type="text" name="confirmed" value="<?php echo $this->input->post('confirmed'); ?>" class="form-control" id="confirmed" />
							<span class="text-danger"><?php echo form_error('confirmed');?></span>
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Enregistrer
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>