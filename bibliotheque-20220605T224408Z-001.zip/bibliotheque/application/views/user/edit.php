<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Modifier un utilisateur</h3>
            </div>
			<?php echo form_open('user/edit/'.$user['id']); ?>
			<div class="box-body">
				<div class="row clearfix">
					<div class="col-md-6">
						<label for="password" class="control-label"><span class="text-danger">*</span>Mot de passe</label>
						<div class="form-group">
							<input type="text" name="password" value="<?php echo ($this->input->post('password') ? $this->input->post('password') : $user['password']); ?>" class="form-control" id="password" />
							<span class="text-danger"><?php echo form_error('password');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="nom" class="control-label"><span class="text-danger">*</span>Nom</label>
						<div class="form-group">
							<input type="text" name="nom" value="<?php echo ($this->input->post('nom') ? $this->input->post('nom') : $user['nom']); ?>" class="form-control" id="nom" />
							<span class="text-danger"><?php echo form_error('nom');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="prenom" class="control-label"><span class="text-danger">*</span>Prénom</label>
						<div class="form-group">
							<input type="text" name="prenom" value="<?php echo ($this->input->post('prenom') ? $this->input->post('prenom') : $user['prenom']); ?>" class="form-control" id="prenom" />
							<span class="text-danger"><?php echo form_error('prenom');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="email" class="control-label"><span class="text-danger">*</span>Email</label>
						<div class="form-group">
							<input type="text" name="email" value="<?php echo ($this->input->post('email') ? $this->input->post('email') : $user['email']); ?>" class="form-control" id="email" />
							<span class="text-danger"><?php echo form_error('email');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="pays" class="control-label">Pays</label>
						<div class="form-group">
							<input type="text" name="pays" value="<?php echo ($this->input->post('pays') ? $this->input->post('pays') : $user['pays']); ?>" class="form-control" id="pays" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="type" class="control-label">Type</label>
						<div class="form-group">
							<input type="text" name="type" value="<?php echo ($this->input->post('type') ? $this->input->post('type') : $user['type']); ?>" class="form-control" id="type" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="created_at" class="control-label">Crée le</label>
						<div class="form-group">
							<input type="text" name="created_at" value="<?php echo ($this->input->post('created_at') ? $this->input->post('created_at') : $user['created_at']); ?>" class="has-datepicker form-control" id="created_at" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="is_payed" class="control-label">Est payé</label>
						<div class="form-group">
							<input type="text" name="is_payed" value="<?php echo ($this->input->post('is_payed') ? $this->input->post('is_payed') : $user['is_payed']); ?>" class="form-control" id="is_payed" />
						</div>
					</div>
					<div class="col-md-6">
						<label for="balance" class="control-label">Balance</label>
						<div class="form-group">
							<input type="text" name="balance" value="<?php echo ($this->input->post('balance') ? $this->input->post('balance') : $user['balance']); ?>" class="form-control" id="balance" />
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Enregistrer
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>