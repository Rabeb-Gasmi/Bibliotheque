<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Ajouter un promo</h3>
            </div>
            <?php echo form_open('promo/add'); ?>
          	<div class="box-body">
          		<div class="row clearfix">
					<div class="col-md-6">
						<label for="document_id" class="control-label"><span class="text-danger">*</span>Document</label>
						<div class="form-group">
							<select name="document_id" class="form-control">
								<option value="">sélectionner le document</option>
								<?php 
								foreach($all_document as $document)
								{
									$selected = ($document['id'] == $this->input->post('document_id')) ? ' selected="selected"' : "";

									echo '<option value="'.$document['id'].'" '.$selected.'>'.$document['id'].'</option>';
								} 
								?>
							</select>
							<span class="text-danger"><?php echo form_error('document_id');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="prix" class="control-label"><span class="text-danger">*</span>Prix</label>
						<div class="form-group">
							<input type="text" name="prix" value="<?php echo $this->input->post('prix'); ?>" class="form-control" id="prix" />
							<span class="text-danger"><?php echo form_error('prix');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="date_debut" class="control-label"><span class="text-danger">*</span>Date Debut</label>
						<div class="form-group">
							<input type="text" name="date_debut" value="<?php echo $this->input->post('date_debut'); ?>" class="has-datepicker form-control" id="date_debut" />
							<span class="text-danger"><?php echo form_error('date_debut');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="date_fin" class="control-label"><span class="text-danger">*</span>Date Fin</label>
						<div class="form-group">
							<input type="text" name="date_fin" value="<?php echo $this->input->post('date_fin'); ?>" class="has-datepicker form-control" id="date_fin" />
							<span class="text-danger"><?php echo form_error('date_fin');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="titre" class="control-label"><span class="text-danger">*</span>Titre</label>
						<div class="form-group">
							<input type="text" name="titre" value="<?php echo $this->input->post('titre'); ?>" class="form-control" id="titre" />
							<span class="text-danger"><?php echo form_error('titre');?></span>
						</div>
					</div>
				</div>
			</div>
          	<div class="box-footer">
            	<button type="submit" class="btn btn-success">
            		<i class="fa fa-check"></i> Enregistrer
            	</button>
          	</div>
            <?php echo form_close(); ?>
      	</div>
    </div>
</div>