<div class="row">
    <div class="col-md-12">
      	<div class="box box-info">
            <div class="box-header with-border">
              	<h3 class="box-title">Modifier un avi</h3>
            </div>
			<?php echo form_open('avi/edit/'.$avi['id']); ?>
			<div class="box-body">
				<div class="row clearfix">
					<div class="col-md-6">
						<label for="document_id" class="control-label"><span class="text-danger">*</span>Document</label>
						<div class="form-group">
							<select name="document_id" class="form-control">
								<option value="">sélectionner le document</option>
								<?php 
								foreach($all_document as $document)
								{
									$selected = ($document['id'] == $avi['document_id']) ? ' selected="selected"' : "";

									echo '<option value="'.$document['id'].'" '.$selected.'>'.$document['id'].'</option>';
								} 
								?>
							</select>
							<span class="text-danger"><?php echo form_error('document_id');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="users_id" class="control-label"><span class="text-danger">*</span>Utilisateur</label>
						<div class="form-group">
							<select name="users_id" class="form-control">
								<option value="">sélectionner l'utilisateur</option>
								<?php 
								foreach($all_users as $user)
								{
									$selected = ($user['id'] == $avi['users_id']) ? ' selected="selected"' : "";

									echo '<option value="'.$user['id'].'" '.$selected.'>'.$user['id'].'</option>';
								} 
								?>
							</select>
							<span class="text-danger"><?php echo form_error('users_id');?></span>
						</div>
					</div>
					<div class="col-md-6">
						<label for="nombre" class="control-label">Nombre</label>
						<div class="form-group">
							<input type="text" name="nombre" value="<?php echo ($this->input->post('nombre') ? $this->input->post('nombre') : $avi['nombre']); ?>" class="form-control" id="nombre" />
						</div>
					</div>
				</div>
			</div>
			<div class="box-footer">
            	<button type="submit" class="btn btn-success">
					<i class="fa fa-check"></i> Enregistrer
				</button>
	        </div>				
			<?php echo form_close(); ?>
		</div>
    </div>
</div>