<?php

 
class Avi extends CI_Controller{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Avi_model');
    } 

    /*
     * Listing of avis
     */
    function index()
    {
        $params['limit'] = RECORDS_PER_PAGE; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('avi/index?');
        $config['total_rows'] = $this->Avi_model->get_all_avis_count();
        $this->pagination->initialize($config);

        $data['avis'] = $this->Avi_model->get_all_avis($params);
        
        $data['_view'] = 'avi/index';
        $this->load->view('layouts/main',$data);
    }

    /*
     * Adding a new avi
     */
    function add()
    {   
        $this->load->library('form_validation');

		$this->form_validation->set_rules('document_id','Document Id','required');
		$this->form_validation->set_rules('users_id','Users Id','required');
		
		if($this->form_validation->run())     
        {   
            $params = array(
				'document_id' => $this->input->post('document_id'),
				'users_id' => $this->input->post('users_id'),
				'nombre' => $this->input->post('nombre'),
            );
            
            $avi_id = $this->Avi_model->add_avi($params);
            redirect('avi/index');
        }
        else
        {
			$this->load->model('Document_model');
			$data['all_document'] = $this->Document_model->get_all_document();

			$this->load->model('User_model');
			$data['all_users'] = $this->User_model->get_all_users();
            
            $data['_view'] = 'avi/add';
            $this->load->view('layouts/main',$data);
        }
    }  

    /*
     * Editing a avi
     */
    function edit($id)
    {   
        // check if the avi exists before trying to edit it
        $data['avi'] = $this->Avi_model->get_avi($id);
        
        if(isset($data['avi']['id']))
        {
            $this->load->library('form_validation');

			$this->form_validation->set_rules('document_id','Document Id','required');
			$this->form_validation->set_rules('users_id','Users Id','required');
		
			if($this->form_validation->run())     
            {   
                $params = array(
					'document_id' => $this->input->post('document_id'),
					'users_id' => $this->input->post('users_id'),
					'nombre' => $this->input->post('nombre'),
                );

                $this->Avi_model->update_avi($id,$params);            
                redirect('avi/index');
            }
            else
            {
				$this->load->model('Document_model');
				$data['all_document'] = $this->Document_model->get_all_document();

				$this->load->model('User_model');
				$data['all_users'] = $this->User_model->get_all_users();

                $data['_view'] = 'avi/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The avi you are trying to edit does not exist.');
    } 

    /*
     * Deleting avi
     */
    function remove($id)
    {
        $avi = $this->Avi_model->get_avi($id);

        // check if the avi exists before trying to delete it
        if(isset($avi['id']))
        {
            $this->Avi_model->delete_avi($id);
            redirect('avi/index');
        }
        else
            show_error('The avi you are trying to delete does not exist.');
    }
    
}
