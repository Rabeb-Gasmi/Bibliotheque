<?php

 
class Commentaire extends CI_Controller{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Commentaire_model');
    } 

    /*
     * Listing of commentaire
     */
    function index()
    {
        $params['limit'] = RECORDS_PER_PAGE; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('commentaire/index?');
        $config['total_rows'] = $this->Commentaire_model->get_all_commentaire_count();
        $this->pagination->initialize($config);

        $data['commentaire'] = $this->Commentaire_model->get_all_commentaire($params);
        
        $data['_view'] = 'commentaire/index';
        $this->load->view('layouts/main',$data);
    }

    /*
     * Adding a new commentaire
     */
    function add()
    {   
        $this->load->library('form_validation');

		$this->form_validation->set_rules('document_id','Document Id','required');
		$this->form_validation->set_rules('users_id','Users Id','required');
		$this->form_validation->set_rules('created_at','Created At','required');
		
		if($this->form_validation->run())     
        {   
            $params = array(
				'document_id' => $this->input->post('document_id'),
				'users_id' => $this->input->post('users_id'),
				'texte' => $this->input->post('texte'),
				'created_at' => $this->input->post('created_at'),
            );
            
            $commentaire_id = $this->Commentaire_model->add_commentaire($params);
            redirect('commentaire/index');
        }
        else
        {
			$this->load->model('Document_model');
			$data['all_document'] = $this->Document_model->get_all_document();

			$this->load->model('User_model');
			$data['all_users'] = $this->User_model->get_all_users();
            
            $data['_view'] = 'commentaire/add';
            $this->load->view('layouts/main',$data);
        }
    }  

    /*
     * Editing a commentaire
     */
    function edit($id)
    {   
        // check if the commentaire exists before trying to edit it
        $data['commentaire'] = $this->Commentaire_model->get_commentaire($id);
        
        if(isset($data['commentaire']['id']))
        {
            $this->load->library('form_validation');

			$this->form_validation->set_rules('document_id','Document Id','required');
			$this->form_validation->set_rules('users_id','Users Id','required');
			$this->form_validation->set_rules('created_at','Created At','required');
		
			if($this->form_validation->run())     
            {   
                $params = array(
					'document_id' => $this->input->post('document_id'),
					'users_id' => $this->input->post('users_id'),
					'texte' => $this->input->post('texte'),
					'created_at' => $this->input->post('created_at'),
                );

                $this->Commentaire_model->update_commentaire($id,$params);            
                redirect('commentaire/index');
            }
            else
            {
				$this->load->model('Document_model');
				$data['all_document'] = $this->Document_model->get_all_document();

				$this->load->model('User_model');
				$data['all_users'] = $this->User_model->get_all_users();

                $data['_view'] = 'commentaire/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The commentaire you are trying to edit does not exist.');
    } 

    /*
     * Deleting commentaire
     */
    function remove($id)
    {
        $commentaire = $this->Commentaire_model->get_commentaire($id);

        // check if the commentaire exists before trying to delete it
        if(isset($commentaire['id']))
        {
            $this->Commentaire_model->delete_commentaire($id);
            redirect('commentaire/index');
        }
        else
            show_error('The commentaire you are trying to delete does not exist.');
    }
    
}
