<?php

 
class Demanderetrait extends CI_Controller{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Demanderetrait_model');
    } 

    /*
     * Listing of demanderetrait
     */
    function index()
    {
        $params['limit'] = RECORDS_PER_PAGE; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('demanderetrait/index?');
        $config['total_rows'] = $this->Demanderetrait_model->get_all_demanderetrait_count();
        $this->pagination->initialize($config);

        $data['demanderetrait'] = $this->Demanderetrait_model->get_all_demanderetrait($params);
        
        $data['_view'] = 'demanderetrait/index';
        $this->load->view('layouts/main',$data);
    }

    /*
     * Adding a new demanderetrait
     */
    function add()
    {   
        $this->load->library('form_validation');

		$this->form_validation->set_rules('users_id','Users Id','required');
		$this->form_validation->set_rules('date','Date','required');
		$this->form_validation->set_rules('montant','Montant','required');
		$this->form_validation->set_rules('confirmed','Confirmed','required');
		
		if($this->form_validation->run())     
        {   
            $params = array(
				'users_id' => $this->input->post('users_id'),
				'date' => $this->input->post('date'),
				'montant' => $this->input->post('montant'),
				'confirmed' => $this->input->post('confirmed'),
            );
            
            $demanderetrait_id = $this->Demanderetrait_model->add_demanderetrait($params);
            redirect('demanderetrait/index');
        }
        else
        {
			$this->load->model('User_model');
			$data['all_users'] = $this->User_model->get_all_users();
            
            $data['_view'] = 'demanderetrait/add';
            $this->load->view('layouts/main',$data);
        }
    }  

    /*
     * Editing a demanderetrait
     */
    function edit($id)
    {   
        // check if the demanderetrait exists before trying to edit it
        $data['demanderetrait'] = $this->Demanderetrait_model->get_demanderetrait($id);
        
        if(isset($data['demanderetrait']['id']))
        {
            $this->load->library('form_validation');

			$this->form_validation->set_rules('users_id','Users Id','required');
			$this->form_validation->set_rules('date','Date','required');
			$this->form_validation->set_rules('montant','Montant','required');
			$this->form_validation->set_rules('confirmed','Confirmed','required');
		
			if($this->form_validation->run())     
            {   
                $params = array(
					'users_id' => $this->input->post('users_id'),
					'date' => $this->input->post('date'),
					'montant' => $this->input->post('montant'),
					'confirmed' => $this->input->post('confirmed'),
                );

                $this->Demanderetrait_model->update_demanderetrait($id,$params);            
                redirect('demanderetrait/index');
            }
            else
            {
				$this->load->model('User_model');
				$data['all_users'] = $this->User_model->get_all_users();

                $data['_view'] = 'demanderetrait/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The demanderetrait you are trying to edit does not exist.');
    } 

    /*
     * Deleting demanderetrait
     */
    function remove($id)
    {
        $demanderetrait = $this->Demanderetrait_model->get_demanderetrait($id);

        // check if the demanderetrait exists before trying to delete it
        if(isset($demanderetrait['id']))
        {
            $this->Demanderetrait_model->delete_demanderetrait($id);
            redirect('demanderetrait/index');
        }
        else
            show_error('The demanderetrait you are trying to delete does not exist.');
    }
    
}
