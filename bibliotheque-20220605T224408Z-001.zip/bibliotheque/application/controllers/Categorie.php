<?php

class Categorie extends CI_Controller{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Categorie_model');
    } 

    /*
     * Listing of categorie
     */
    function index()
    {
        $params['limit'] = RECORDS_PER_PAGE; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('categorie/index?');
        $config['total_rows'] = $this->Categorie_model->get_all_categorie_count();
        $this->pagination->initialize($config);

        $data['categorie'] = $this->Categorie_model->get_all_categorie($params);
        
        $data['_view'] = 'categorie/index';
        $this->load->view('layouts/main',$data);
    }

    /*
     * Adding a new categorie
     */
    function add()
    {   
        $this->load->library('form_validation');

		$this->form_validation->set_rules('titre','Titre','required');
		
		if($this->form_validation->run())     
        {   
            $params = array(
				'titre' => $this->input->post('titre'),
				'description' => $this->input->post('description'),
            );
            
            $categorie_id = $this->Categorie_model->add_categorie($params);
            redirect('categorie/index');
        }
        else
        {            
            $data['_view'] = 'categorie/add';
            $this->load->view('layouts/main',$data);
        }
    }  

    /*
     * Editing a categorie
     */
    function edit($id)
    {   
        // check if the categorie exists before trying to edit it
        $data['categorie'] = $this->Categorie_model->get_categorie($id);
        
        if(isset($data['categorie']['id']))
        {
            $this->load->library('form_validation');

			$this->form_validation->set_rules('titre','Titre','required');
		
			if($this->form_validation->run())     
            {   
                $params = array(
					'titre' => $this->input->post('titre'),
					'description' => $this->input->post('description'),
                );

                $this->Categorie_model->update_categorie($id,$params);            
                redirect('categorie/index');
            }
            else
            {
                $data['_view'] = 'categorie/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The categorie you are trying to edit does not exist.');
    } 

    /*
     * Deleting categorie
     */
    function remove($id)
    {
        $categorie = $this->Categorie_model->get_categorie($id);

        // check if the categorie exists before trying to delete it
        if(isset($categorie['id']))
        {
            $this->Categorie_model->delete_categorie($id);
            redirect('categorie/index');
        }
        else
            show_error('The categorie you are trying to delete does not exist.');
    }
    
}
