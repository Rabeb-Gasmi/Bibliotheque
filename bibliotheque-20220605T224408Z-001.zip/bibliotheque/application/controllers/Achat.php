<?php

 
class Achat extends CI_Controller{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Achat_model');
    } 

    /*
     * Listing of achat
     */
    function index()
    {
        $params['limit'] = RECORDS_PER_PAGE; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('achat/index?');
        $config['total_rows'] = $this->Achat_model->get_all_achat_count();
        $this->pagination->initialize($config);

        $data['achat'] = $this->Achat_model->get_all_achat($params);
        
        $data['_view'] = 'achat/index';
        $this->load->view('layouts/main',$data);
    }

    /*
     * Adding a new achat
     */
    function add()
    {   
        $this->load->library('form_validation');

		$this->form_validation->set_rules('users_id','Users Id','required');
		$this->form_validation->set_rules('document_id','Document Id','required');
		
		if($this->form_validation->run())     
        {   
            $params = array(
				'users_id' => $this->input->post('users_id'),
				'document_id' => $this->input->post('document_id'),
				'date' => $this->input->post('date'),
				'prix' => $this->input->post('prix'),
				'commision' => $this->input->post('commision'),
				'net' => $this->input->post('net'),
            );
            
            $achat_id = $this->Achat_model->add_achat($params);
            redirect('achat/index');
        }
        else
        {
			$this->load->model('User_model');
			$data['all_users'] = $this->User_model->get_all_users();

			$this->load->model('Document_model');
			$data['all_document'] = $this->Document_model->get_all_document();
            
            $data['_view'] = 'achat/add';
            $this->load->view('layouts/main',$data);
        }
    }  

    /*
     * Editing a achat
     */
    function edit($id)
    {   
        // check if the achat exists before trying to edit it
        $data['achat'] = $this->Achat_model->get_achat($id);
        
        if(isset($data['achat']['id']))
        {
            $this->load->library('form_validation');

			$this->form_validation->set_rules('users_id','Users Id','required');
			$this->form_validation->set_rules('document_id','Document Id','required');
		
			if($this->form_validation->run())     
            {   
                $params = array(
					'users_id' => $this->input->post('users_id'),
					'document_id' => $this->input->post('document_id'),
					'date' => $this->input->post('date'),
					'prix' => $this->input->post('prix'),
					'commision' => $this->input->post('commision'),
					'net' => $this->input->post('net'),
                );

                $this->Achat_model->update_achat($id,$params);            
                redirect('achat/index');
            }
            else
            {
				$this->load->model('User_model');
				$data['all_users'] = $this->User_model->get_all_users();

				$this->load->model('Document_model');
				$data['all_document'] = $this->Document_model->get_all_document();

                $data['_view'] = 'achat/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The achat you are trying to edit does not exist.');
    } 

    /*
     * Deleting achat
     */
    function remove($id)
    {
        $achat = $this->Achat_model->get_achat($id);

        // check if the achat exists before trying to delete it
        if(isset($achat['id']))
        {
            $this->Achat_model->delete_achat($id);
            redirect('achat/index');
        }
        else
            show_error('The achat you are trying to delete does not exist.');
    }
    
}
