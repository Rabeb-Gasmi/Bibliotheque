<?php

 
class Abonnement extends CI_Controller{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Abonnement_model');
    } 

    /*
     * Listing of abonnement
     */
    function index()
    {
        $params['limit'] = RECORDS_PER_PAGE; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('abonnement/index?');
        $config['total_rows'] = $this->Abonnement_model->get_all_abonnement_count();
        $this->pagination->initialize($config);

        $data['abonnement'] = $this->Abonnement_model->get_all_abonnement($params);
        
        $data['_view'] = 'abonnement/index';
        $this->load->view('layouts/main',$data);
    }

    /*
     * Adding a new abonnement
     */
    function add()
    {   
        $this->load->library('form_validation');

		$this->form_validation->set_rules('users_id','Users Id','required');
		$this->form_validation->set_rules('tarif_id','Tarif Id','required');
		$this->form_validation->set_rules('prix','Prix','required');
		$this->form_validation->set_rules('date_debut','Date Debut','required');
		$this->form_validation->set_rules('date_fin','Date Fin','required');
		
		if($this->form_validation->run())     
        {   
            $params = array(
				'users_id' => $this->input->post('users_id'),
				'tarif_id' => $this->input->post('tarif_id'),
				'prix' => $this->input->post('prix'),
				'date_debut' => $this->input->post('date_debut'),
				'date_fin' => $this->input->post('date_fin'),
            );
            
            $abonnement_id = $this->Abonnement_model->add_abonnement($params);
            redirect('abonnement/index');
        }
        else
        {
			$this->load->model('User_model');
			$data['all_users'] = $this->User_model->get_all_users();

			$this->load->model('Tarif_model');
			$data['all_tarif'] = $this->Tarif_model->get_all_tarif();
            
            $data['_view'] = 'abonnement/add';
            $this->load->view('layouts/main',$data);
        }
    }  

    /*
     * Editing a abonnement
     */
    function edit($id)
    {   
        // check if the abonnement exists before trying to edit it
        $data['abonnement'] = $this->Abonnement_model->get_abonnement($id);
        
        if(isset($data['abonnement']['id']))
        {
            $this->load->library('form_validation');

			$this->form_validation->set_rules('users_id','Users Id','required');
			$this->form_validation->set_rules('tarif_id','Tarif Id','required');
			$this->form_validation->set_rules('prix','Prix','required');
			$this->form_validation->set_rules('date_debut','Date Debut','required');
			$this->form_validation->set_rules('date_fin','Date Fin','required');
		
			if($this->form_validation->run())     
            {   
                $params = array(
					'users_id' => $this->input->post('users_id'),
					'tarif_id' => $this->input->post('tarif_id'),
					'prix' => $this->input->post('prix'),
					'date_debut' => $this->input->post('date_debut'),
					'date_fin' => $this->input->post('date_fin'),
                );

                $this->Abonnement_model->update_abonnement($id,$params);            
                redirect('abonnement/index');
            }
            else
            {
				$this->load->model('User_model');
				$data['all_users'] = $this->User_model->get_all_users();

				$this->load->model('Tarif_model');
				$data['all_tarif'] = $this->Tarif_model->get_all_tarif();

                $data['_view'] = 'abonnement/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The abonnement you are trying to edit does not exist.');
    } 

    /*
     * Deleting abonnement
     */
    function remove($id)
    {
        $abonnement = $this->Abonnement_model->get_abonnement($id);

        // check if the abonnement exists before trying to delete it
        if(isset($abonnement['id']))
        {
            $this->Abonnement_model->delete_abonnement($id);
            redirect('abonnement/index');
        }
        else
            show_error('The abonnement you are trying to delete does not exist.');
    }
    
}
