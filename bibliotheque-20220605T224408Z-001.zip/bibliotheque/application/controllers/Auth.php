<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->model('Auth_model');
	}
	
	public function index() {
		$session = $this->session->userdata('status');

		if ($session == '') {
			$this->load->view('login');
		} else {
			redirect('Main');
		}
	}

	public function login() {
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');

		$this->form_validation->set_rules('email', 'Email', 'required|min_length[10]|max_length[100]');
		$this->form_validation->set_rules('password', 'Password', 'required');
		
		if ($this->form_validation->run() == TRUE) {
			$username = trim($_POST['email']);
			$password = trim($_POST['password']);

			$data = $this->Auth_model->login($email, $password);

			if ($data == false) {
				$this->session->set_flashdata('error_msg', 'Email / Password .');
				redirect('Main');
			} else {
				$session = [
					'userdata' => $data,
					'status' => "Loged in"
				];
				$this->session->set_userdata($session);
				redirect('Main');
			}
		} else {
			$this->session->set_flashdata('error_msg', validation_errors());
			redirect('Main');
		}
	}

	public function logout() {
		$this->session->sess_destroy();
		redirect('Auth');
	}
}
