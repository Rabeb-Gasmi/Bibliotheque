<?php
class Theme extends CI_Controller{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Theme_model');
    } 

    /*
     * Listing of theme
     */
    function index()
    {
        $params['limit'] = RECORDS_PER_PAGE; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('theme/index?');
        $config['total_rows'] = $this->Theme_model->get_all_theme_count();
        $this->pagination->initialize($config);

        $data['theme'] = $this->Theme_model->get_all_theme($params);
        
        $data['_view'] = 'theme/index';
        $this->load->view('layouts/main',$data);
    }

    /*
     * Adding a new theme
     */
    function add()
    {   
        $this->load->library('form_validation');

		$this->form_validation->set_rules('titre','Titre','required');
		
		if($this->form_validation->run())     
        {   
            $params = array(
				'titre' => $this->input->post('titre'),
				'description' => $this->input->post('description'),
            );
            
            $theme_id = $this->Theme_model->add_theme($params);
            redirect('theme/index');
        }
        else
        {            
            $data['_view'] = 'theme/add';
            $this->load->view('layouts/main',$data);
        }
    }  

    /*
     * Editing a theme
     */
    function edit($id)
    {   
        // check if the theme exists before trying to edit it
        $data['theme'] = $this->Theme_model->get_theme($id);
        
        if(isset($data['theme']['id']))
        {
            $this->load->library('form_validation');

			$this->form_validation->set_rules('titre','Titre','required');
		
			if($this->form_validation->run())     
            {   
                $params = array(
					'titre' => $this->input->post('titre'),
					'description' => $this->input->post('description'),
                );

                $this->Theme_model->update_theme($id,$params);            
                redirect('theme/index');
            }
            else
            {
                $data['_view'] = 'theme/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The theme you are trying to edit does not exist.');
    } 

    /*
     * Deleting theme
     */
    function remove($id)
    {
        $theme = $this->Theme_model->get_theme($id);

        // check if the theme exists before trying to delete it
        if(isset($theme['id']))
        {
            $this->Theme_model->delete_theme($id);
            redirect('theme/index');
        }
        else
            show_error('The theme you are trying to delete does not exist.');
    }
    
}
