<?php

class Tarif extends CI_Controller{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Tarif_model');
    } 

    /*
     * Listing of tarif
     */
    function index()
    {
        $params['limit'] = RECORDS_PER_PAGE; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('tarif/index?');
        $config['total_rows'] = $this->Tarif_model->get_all_tarif_count();
        $this->pagination->initialize($config);

        $data['tarif'] = $this->Tarif_model->get_all_tarif($params);
        
        $data['_view'] = 'tarif/index';
        $this->load->view('layouts/main',$data);
    }

    /*
     * Adding a new tarif
     */
    function add()
    {   
        $this->load->library('form_validation');

		$this->form_validation->set_rules('prix','Prix','required');
		$this->form_validation->set_rules('duree','Duree','required');
		
		if($this->form_validation->run())     
        {   
            $params = array(
				'duree' => $this->input->post('duree'),
				'prix' => $this->input->post('prix'),
            );
            
            $tarif_id = $this->Tarif_model->add_tarif($params);
            redirect('tarif/index');
        }
        else
        {            
            $data['_view'] = 'tarif/add';
            $this->load->view('layouts/main',$data);
        }
    }  

    /*
     * Editing a tarif
     */
    function edit($id)
    {   
        // check if the tarif exists before trying to edit it
        $data['tarif'] = $this->Tarif_model->get_tarif($id);
        
        if(isset($data['tarif']['id']))
        {
            $this->load->library('form_validation');

			$this->form_validation->set_rules('prix','Prix','required');
			$this->form_validation->set_rules('duree','Duree','required');
		
			if($this->form_validation->run())     
            {   
                $params = array(
					'duree' => $this->input->post('duree'),
					'prix' => $this->input->post('prix'),
                );

                $this->Tarif_model->update_tarif($id,$params);            
                redirect('tarif/index');
            }
            else
            {
                $data['_view'] = 'tarif/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The tarif you are trying to edit does not exist.');
    } 

    /*
     * Deleting tarif
     */
    function remove($id)
    {
        $tarif = $this->Tarif_model->get_tarif($id);

        // check if the tarif exists before trying to delete it
        if(isset($tarif['id']))
        {
            $this->Tarif_model->delete_tarif($id);
            redirect('tarif/index');
        }
        else
            show_error('The tarif you are trying to delete does not exist.');
    }
    
}
