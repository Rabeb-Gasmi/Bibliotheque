<?php
class Document extends CI_Controller{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Document_model');
    } 

    /*
     * Listing of document
     */
    function index()
    {
        $params['limit'] = RECORDS_PER_PAGE; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('document/index?');
        $config['total_rows'] = $this->Document_model->get_all_document_count();
        $this->pagination->initialize($config);

        $data['document'] = $this->Document_model->get_all_document($params);
        
        $data['_view'] = 'document/index';
        $this->load->view('layouts/main',$data);
    }

    /*
     * Adding a new document
     */
    function add()
    {   
        $this->load->library('form_validation');

		$this->form_validation->set_rules('users_id','Users Id','required');
		$this->form_validation->set_rules('theme_id','Theme Id','required');
		$this->form_validation->set_rules('categorie_id','Categorie Id','required');
		$this->form_validation->set_rules('titre','Titre','required');
		$this->form_validation->set_rules('prix','Prix','required');
		$this->form_validation->set_rules('created_at','Created At','required');
		
		if($this->form_validation->run())     
        {   
            $params = array(
				'users_id' => $this->input->post('users_id'),
				'theme_id' => $this->input->post('theme_id'),
				'categorie_id' => $this->input->post('categorie_id'),
				'titre' => $this->input->post('titre'),
				'auteur' => $this->input->post('auteur'),
				'description' => $this->input->post('description'),
				'volume' => $this->input->post('volume'),
				'annee' => $this->input->post('annee'),
				'prix' => $this->input->post('prix'),
				'created_at' => $this->input->post('created_at'),
            );
            
            $document_id = $this->Document_model->add_document($params);
            redirect('document/index');
        }
        else
        {
			$this->load->model('User_model');
			$data['all_users'] = $this->User_model->get_all_users();

			$this->load->model('Theme_model');
			$data['all_theme'] = $this->Theme_model->get_all_theme();

			$this->load->model('Categorie_model');
			$data['all_categorie'] = $this->Categorie_model->get_all_categorie();
            
            $data['_view'] = 'document/add';
            $this->load->view('layouts/main',$data);
        }
    }  

    /*
     * Editing a document
     */
    function edit($id)
    {   
        // check if the document exists before trying to edit it
        $data['document'] = $this->Document_model->get_document($id);
        
        if(isset($data['document']['id']))
        {
            $this->load->library('form_validation');

			$this->form_validation->set_rules('users_id','Users Id','required');
			$this->form_validation->set_rules('theme_id','Theme Id','required');
			$this->form_validation->set_rules('categorie_id','Categorie Id','required');
			$this->form_validation->set_rules('titre','Titre','required');
			$this->form_validation->set_rules('prix','Prix','required');
			$this->form_validation->set_rules('created_at','Created At','required');
		
			if($this->form_validation->run())     
            {   
                $params = array(
					'users_id' => $this->input->post('users_id'),
					'theme_id' => $this->input->post('theme_id'),
					'categorie_id' => $this->input->post('categorie_id'),
					'titre' => $this->input->post('titre'),
					'auteur' => $this->input->post('auteur'),
					'description' => $this->input->post('description'),
					'volume' => $this->input->post('volume'),
					'annee' => $this->input->post('annee'),
					'prix' => $this->input->post('prix'),
					'created_at' => $this->input->post('created_at'),
                );

                $this->Document_model->update_document($id,$params);            
                redirect('document/index');
            }
            else
            {
				$this->load->model('User_model');
				$data['all_users'] = $this->User_model->get_all_users();

				$this->load->model('Theme_model');
				$data['all_theme'] = $this->Theme_model->get_all_theme();

				$this->load->model('Categorie_model');
				$data['all_categorie'] = $this->Categorie_model->get_all_categorie();

                $data['_view'] = 'document/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The document you are trying to edit does not exist.');
    } 

    /*
     * Deleting document
     */
    function remove($id)
    {
        $document = $this->Document_model->get_document($id);

        // check if the document exists before trying to delete it
        if(isset($document['id']))
        {
            $this->Document_model->delete_document($id);
            redirect('document/index');
        }
        else
            show_error('The document you are trying to delete does not exist.');
    }
    
}
