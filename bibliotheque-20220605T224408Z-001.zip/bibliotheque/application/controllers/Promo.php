<?php

class Promo extends CI_Controller{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Promo_model');
    } 

    /*
     * Listing of promos
     */
    function index()
    {
        $params['limit'] = RECORDS_PER_PAGE; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('promo/index?');
        $config['total_rows'] = $this->Promo_model->get_all_promos_count();
        $this->pagination->initialize($config);

        $data['promos'] = $this->Promo_model->get_all_promos($params);
        
        $data['_view'] = 'promo/index';
        $this->load->view('layouts/main',$data);
    }

    /*
     * Adding a new promo
     */
    function add()
    {   
        $this->load->library('form_validation');

		$this->form_validation->set_rules('document_id','Document Id','required');
		$this->form_validation->set_rules('prix','Prix','required');
		$this->form_validation->set_rules('date_debut','Date Debut','required');
		$this->form_validation->set_rules('date_fin','Date Fin','required');
		$this->form_validation->set_rules('titre','Titre','required');
		
		if($this->form_validation->run())     
        {   
            $params = array(
				'document_id' => $this->input->post('document_id'),
				'prix' => $this->input->post('prix'),
				'date_debut' => $this->input->post('date_debut'),
				'date_fin' => $this->input->post('date_fin'),
				'titre' => $this->input->post('titre'),
            );
            
            $promo_id = $this->Promo_model->add_promo($params);
            redirect('promo/index');
        }
        else
        {
			$this->load->model('Document_model');
			$data['all_document'] = $this->Document_model->get_all_document();
            
            $data['_view'] = 'promo/add';
            $this->load->view('layouts/main',$data);
        }
    }  

    /*
     * Editing a promo
     */
    function edit($id)
    {   
        // check if the promo exists before trying to edit it
        $data['promo'] = $this->Promo_model->get_promo($id);
        
        if(isset($data['promo']['id']))
        {
            $this->load->library('form_validation');

			$this->form_validation->set_rules('document_id','Document Id','required');
			$this->form_validation->set_rules('prix','Prix','required');
			$this->form_validation->set_rules('date_debut','Date Debut','required');
			$this->form_validation->set_rules('date_fin','Date Fin','required');
			$this->form_validation->set_rules('titre','Titre','required');
		
			if($this->form_validation->run())     
            {   
                $params = array(
					'document_id' => $this->input->post('document_id'),
					'prix' => $this->input->post('prix'),
					'date_debut' => $this->input->post('date_debut'),
					'date_fin' => $this->input->post('date_fin'),
					'titre' => $this->input->post('titre'),
                );

                $this->Promo_model->update_promo($id,$params);            
                redirect('promo/index');
            }
            else
            {
				$this->load->model('Document_model');
				$data['all_document'] = $this->Document_model->get_all_document();

                $data['_view'] = 'promo/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The promo you are trying to edit does not exist.');
    } 

    /*
     * Deleting promo
     */
    function remove($id)
    {
        $promo = $this->Promo_model->get_promo($id);

        // check if the promo exists before trying to delete it
        if(isset($promo['id']))
        {
            $this->Promo_model->delete_promo($id);
            redirect('promo/index');
        }
        else
            show_error('The promo you are trying to delete does not exist.');
    }
    
}
