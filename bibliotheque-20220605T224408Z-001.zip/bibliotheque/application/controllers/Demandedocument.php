<?php
 
class Demandedocument extends CI_Controller{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Demandedocument_model');
    } 

    /*
     * Listing of demandedocument
     */
    function index()
    {
        $params['limit'] = RECORDS_PER_PAGE; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('demandedocument/index?');
        $config['total_rows'] = $this->Demandedocument_model->get_all_demandedocument_count();
        $this->pagination->initialize($config);

        $data['demandedocument'] = $this->Demandedocument_model->get_all_demandedocument($params);
        
        $data['_view'] = 'demandedocument/index';
        $this->load->view('layouts/main',$data);
    }

    /*
     * Adding a new demandedocument
     */
    function add()
    {   
        $this->load->library('form_validation');

		$this->form_validation->set_rules('users_id','Users Id','required');
		
		if($this->form_validation->run())     
        {   
            $params = array(
				'users_id' => $this->input->post('users_id'),
				'texte' => $this->input->post('texte'),
				'image' => $this->input->post('image'),
            );
            
            $demandedocument_id = $this->Demandedocument_model->add_demandedocument($params);
            redirect('demandedocument/index');
        }
        else
        {
			$this->load->model('User_model');
			$data['all_users'] = $this->User_model->get_all_users();
            
            $data['_view'] = 'demandedocument/add';
            $this->load->view('layouts/main',$data);
        }
    }  

    /*
     * Editing a demandedocument
     */
    function edit($id)
    {   
        // check if the demandedocument exists before trying to edit it
        $data['demandedocument'] = $this->Demandedocument_model->get_demandedocument($id);
        
        if(isset($data['demandedocument']['id']))
        {
            $this->load->library('form_validation');

			$this->form_validation->set_rules('users_id','Users Id','required');
		
			if($this->form_validation->run())     
            {   
                $params = array(
					'users_id' => $this->input->post('users_id'),
					'texte' => $this->input->post('texte'),
					'image' => $this->input->post('image'),
                );

                $this->Demandedocument_model->update_demandedocument($id,$params);            
                redirect('demandedocument/index');
            }
            else
            {
				$this->load->model('User_model');
				$data['all_users'] = $this->User_model->get_all_users();

                $data['_view'] = 'demandedocument/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The demandedocument you are trying to edit does not exist.');
    } 

    /*
     * Deleting demandedocument
     */
    function remove($id)
    {
        $demandedocument = $this->Demandedocument_model->get_demandedocument($id);

        // check if the demandedocument exists before trying to delete it
        if(isset($demandedocument['id']))
        {
            $this->Demandedocument_model->delete_demandedocument($id);
            redirect('demandedocument/index');
        }
        else
            show_error('The demandedocument you are trying to delete does not exist.');
    }
    
}
