<?php

 
class Commentairedemande extends CI_Controller{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Commentairedemande_model');
    } 

    /*
     * Listing of commentairedemande
     */
    function index()
    {
        $params['limit'] = RECORDS_PER_PAGE; 
        $params['offset'] = ($this->input->get('per_page')) ? $this->input->get('per_page') : 0;
        
        $config = $this->config->item('pagination');
        $config['base_url'] = site_url('commentairedemande/index?');
        $config['total_rows'] = $this->Commentairedemande_model->get_all_commentairedemande_count();
        $this->pagination->initialize($config);

        $data['commentairedemande'] = $this->Commentairedemande_model->get_all_commentairedemande($params);
        
        $data['_view'] = 'commentairedemande/index';
        $this->load->view('layouts/main',$data);
    }

    /*
     * Adding a new commentairedemande
     */
    function add()
    {   
        $this->load->library('form_validation');

		$this->form_validation->set_rules('document_id','Document Id','required');
		$this->form_validation->set_rules('users_id','Users Id','required');
		
		if($this->form_validation->run())     
        {   
            $params = array(
				'users_id' => $this->input->post('users_id'),
				'document_id' => $this->input->post('document_id'),
				'texte' => $this->input->post('texte'),
            );
            
            $commentairedemande_id = $this->Commentairedemande_model->add_commentairedemande($params);
            redirect('commentairedemande/index');
        }
        else
        {
			$this->load->model('User_model');
			$data['all_users'] = $this->User_model->get_all_users();

			$this->load->model('Document_model');
			$data['all_document'] = $this->Document_model->get_all_document();
            
            $data['_view'] = 'commentairedemande/add';
            $this->load->view('layouts/main',$data);
        }
    }  

    /*
     * Editing a commentairedemande
     */
    function edit($id)
    {   
        // check if the commentairedemande exists before trying to edit it
        $data['commentairedemande'] = $this->Commentairedemande_model->get_commentairedemande($id);
        
        if(isset($data['commentairedemande']['id']))
        {
            $this->load->library('form_validation');

			$this->form_validation->set_rules('document_id','Document Id','required');
			$this->form_validation->set_rules('users_id','Users Id','required');
		
			if($this->form_validation->run())     
            {   
                $params = array(
					'users_id' => $this->input->post('users_id'),
					'document_id' => $this->input->post('document_id'),
					'texte' => $this->input->post('texte'),
                );

                $this->Commentairedemande_model->update_commentairedemande($id,$params);            
                redirect('commentairedemande/index');
            }
            else
            {
				$this->load->model('User_model');
				$data['all_users'] = $this->User_model->get_all_users();

				$this->load->model('Document_model');
				$data['all_document'] = $this->Document_model->get_all_document();

                $data['_view'] = 'commentairedemande/edit';
                $this->load->view('layouts/main',$data);
            }
        }
        else
            show_error('The commentairedemande you are trying to edit does not exist.');
    } 

    /*
     * Deleting commentairedemande
     */
    function remove($id)
    {
        $commentairedemande = $this->Commentairedemande_model->get_commentairedemande($id);

        // check if the commentairedemande exists before trying to delete it
        if(isset($commentairedemande['id']))
        {
            $this->Commentairedemande_model->delete_commentairedemande($id);
            redirect('commentairedemande/index');
        }
        else
            show_error('The commentairedemande you are trying to delete does not exist.');
    }
    
}
