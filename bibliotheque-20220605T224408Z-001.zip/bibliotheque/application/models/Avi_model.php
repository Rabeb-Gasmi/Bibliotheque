<?php

 
class Avi_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
    /*
     * Get avi by id
     */
    function get_avi($id)
    {
        return $this->db->get_where('avis',array('id'=>$id))->row_array();
    }
    
    /*
     * Get all avis count
     */
    function get_all_avis_count()
    {
        $this->db->from('avis');
        return $this->db->count_all_results();
    }
        
    /*
     * Get all avis
     */
    function get_all_avis($params = array())
    {
        $this->db->order_by('id', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        return $this->db->get('avis')->result_array();
    }
        
    /*
     * function to add new avi
     */
    function add_avi($params)
    {
        $this->db->insert('avis',$params);
        return $this->db->insert_id();
    }
    
    /*
     * function to update avi
     */
    function update_avi($id,$params)
    {
        $this->db->where('id',$id);
        return $this->db->update('avis',$params);
    }
    
    /*
     * function to delete avi
     */
    function delete_avi($id)
    {
        return $this->db->delete('avis',array('id'=>$id));
    }
}
