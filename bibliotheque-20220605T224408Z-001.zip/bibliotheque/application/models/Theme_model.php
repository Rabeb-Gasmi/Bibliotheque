<?php

 
class Theme_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
    /*
     * Get theme by id
     */
    function get_theme($id)
    {
        return $this->db->get_where('theme',array('id'=>$id))->row_array();
    }
    
    /*
     * Get all theme count
     */
    function get_all_theme_count()
    {
        $this->db->from('theme');
        return $this->db->count_all_results();
    }
        
    /*
     * Get all theme
     */
    function get_all_theme($params = array())
    {
        $this->db->order_by('id', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        return $this->db->get('theme')->result_array();
    }
        
    /*
     * function to add new theme
     */
    function add_theme($params)
    {
        $this->db->insert('theme',$params);
        return $this->db->insert_id();
    }
    
    /*
     * function to update theme
     */
    function update_theme($id,$params)
    {
        $this->db->where('id',$id);
        return $this->db->update('theme',$params);
    }
    
    /*
     * function to delete theme
     */
    function delete_theme($id)
    {
        return $this->db->delete('theme',array('id'=>$id));
    }
}
