<?php

 
class Promo_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
    /*
     * Get promo by id
     */
    function get_promo($id)
    {
        return $this->db->get_where('promos',array('id'=>$id))->row_array();
    }
    
    /*
     * Get all promos count
     */
    function get_all_promos_count()
    {
        $this->db->from('promos');
        return $this->db->count_all_results();
    }
        
    /*
     * Get all promos
     */
    function get_all_promos($params = array())
    {
        $this->db->order_by('id', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        return $this->db->get('promos')->result_array();
    }
        
    /*
     * function to add new promo
     */
    function add_promo($params)
    {
        $this->db->insert('promos',$params);
        return $this->db->insert_id();
    }
    
    /*
     * function to update promo
     */
    function update_promo($id,$params)
    {
        $this->db->where('id',$id);
        return $this->db->update('promos',$params);
    }
    
    /*
     * function to delete promo
     */
    function delete_promo($id)
    {
        return $this->db->delete('promos',array('id'=>$id));
    }
}
