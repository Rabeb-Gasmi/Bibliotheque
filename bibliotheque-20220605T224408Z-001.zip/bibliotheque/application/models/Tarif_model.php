<?php

 
class Tarif_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
    /*
     * Get tarif by id
     */
    function get_tarif($id)
    {
        return $this->db->get_where('tarif',array('id'=>$id))->row_array();
    }
    
    /*
     * Get all tarif count
     */
    function get_all_tarif_count()
    {
        $this->db->from('tarif');
        return $this->db->count_all_results();
    }
        
    /*
     * Get all tarif
     */
    function get_all_tarif($params = array())
    {
        $this->db->order_by('id', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        return $this->db->get('tarif')->result_array();
    }
        
    /*
     * function to add new tarif
     */
    function add_tarif($params)
    {
        $this->db->insert('tarif',$params);
        return $this->db->insert_id();
    }
    
    /*
     * function to update tarif
     */
    function update_tarif($id,$params)
    {
        $this->db->where('id',$id);
        return $this->db->update('tarif',$params);
    }
    
    /*
     * function to delete tarif
     */
    function delete_tarif($id)
    {
        return $this->db->delete('tarif',array('id'=>$id));
    }
}
