<?php

 
class Commentairedemande_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
    /*
     * Get commentairedemande by id
     */
    function get_commentairedemande($id)
    {
        return $this->db->get_where('commentairedemande',array('id'=>$id))->row_array();
    }
    
    /*
     * Get all commentairedemande count
     */
    function get_all_commentairedemande_count()
    {
        $this->db->from('commentairedemande');
        return $this->db->count_all_results();
    }
        
    /*
     * Get all commentairedemande
     */
    function get_all_commentairedemande($params = array())
    {
        $this->db->order_by('id', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        return $this->db->get('commentairedemande')->result_array();
    }
        
    /*
     * function to add new commentairedemande
     */
    function add_commentairedemande($params)
    {
        $this->db->insert('commentairedemande',$params);
        return $this->db->insert_id();
    }
    
    /*
     * function to update commentairedemande
     */
    function update_commentairedemande($id,$params)
    {
        $this->db->where('id',$id);
        return $this->db->update('commentairedemande',$params);
    }
    
    /*
     * function to delete commentairedemande
     */
    function delete_commentairedemande($id)
    {
        return $this->db->delete('commentairedemande',array('id'=>$id));
    }
}
