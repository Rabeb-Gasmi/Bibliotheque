<?php

 
class Demanderetrait_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
    /*
     * Get demanderetrait by id
     */
    function get_demanderetrait($id)
    {
        return $this->db->get_where('demanderetrait',array('id'=>$id))->row_array();
    }
    
    /*
     * Get all demanderetrait count
     */
    function get_all_demanderetrait_count()
    {
        $this->db->from('demanderetrait');
        return $this->db->count_all_results();
    }
        
    /*
     * Get all demanderetrait
     */
    function get_all_demanderetrait($params = array())
    {
        $this->db->order_by('id', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        return $this->db->get('demanderetrait')->result_array();
    }
        
    /*
     * function to add new demanderetrait
     */
    function add_demanderetrait($params)
    {
        $this->db->insert('demanderetrait',$params);
        return $this->db->insert_id();
    }
    
    /*
     * function to update demanderetrait
     */
    function update_demanderetrait($id,$params)
    {
        $this->db->where('id',$id);
        return $this->db->update('demanderetrait',$params);
    }
    
    /*
     * function to delete demanderetrait
     */
    function delete_demanderetrait($id)
    {
        return $this->db->delete('demanderetrait',array('id'=>$id));
    }
}
