<?php

 
class Abonnement_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
    /*
     * Get abonnement by id
     */
    function get_abonnement($id)
    {
        return $this->db->get_where('abonnement',array('id'=>$id))->row_array();
    }
    
    /*
     * Get all abonnement count
     */
    function get_all_abonnement_count()
    {
        $this->db->from('abonnement');
        return $this->db->count_all_results();
    }
        
    /*
     * Get all abonnement
     */
    function get_all_abonnement($params = array())
    {
        $this->db->order_by('id', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        return $this->db->get('abonnement')->result_array();
    }
        
    /*
     * function to add new abonnement
     */
    function add_abonnement($params)
    {
        $this->db->insert('abonnement',$params);
        return $this->db->insert_id();
    }
    
    /*
     * function to update abonnement
     */
    function update_abonnement($id,$params)
    {
        $this->db->where('id',$id);
        return $this->db->update('abonnement',$params);
    }
    
    /*
     * function to delete abonnement
     */
    function delete_abonnement($id)
    {
        return $this->db->delete('abonnement',array('id'=>$id));
    }
}
