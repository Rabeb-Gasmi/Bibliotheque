<?php

 
class Document_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
    /*
     * Get document by id
     */
    function get_document($id)
    {
        return $this->db->get_where('document',array('id'=>$id))->row_array();
    }
    
    /*
     * Get all document count
     */
    function get_all_document_count()
    {
        $this->db->from('document');
        return $this->db->count_all_results();
    }
        
    /*
     * Get all document
     */
    function get_all_document($params = array())
    {
        $this->db->order_by('id', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        return $this->db->get('document')->result_array();
    }
        
    /*
     * function to add new document
     */
    function add_document($params)
    {
        $this->db->insert('document',$params);
        return $this->db->insert_id();
    }
    
    /*
     * function to update document
     */
    function update_document($id,$params)
    {
        $this->db->where('id',$id);
        return $this->db->update('document',$params);
    }
    
    /*
     * function to delete document
     */
    function delete_document($id)
    {
        return $this->db->delete('document',array('id'=>$id));
    }
}
