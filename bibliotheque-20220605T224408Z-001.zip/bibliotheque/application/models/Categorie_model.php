<?php

 
class Categorie_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
    /*
     * Get categorie by id
     */
    function get_categorie($id)
    {
        return $this->db->get_where('categorie',array('id'=>$id))->row_array();
    }
    
    /*
     * Get all categorie count
     */
    function get_all_categorie_count()
    {
        $this->db->from('categorie');
        return $this->db->count_all_results();
    }
        
    /*
     * Get all categorie
     */
    function get_all_categorie($params = array())
    {
        $this->db->order_by('id', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        return $this->db->get('categorie')->result_array();
    }
        
    /*
     * function to add new categorie
     */
    function add_categorie($params)
    {
        $this->db->insert('categorie',$params);
        return $this->db->insert_id();
    }
    
    /*
     * function to update categorie
     */
    function update_categorie($id,$params)
    {
        $this->db->where('id',$id);
        return $this->db->update('categorie',$params);
    }
    
    /*
     * function to delete categorie
     */
    function delete_categorie($id)
    {
        return $this->db->delete('categorie',array('id'=>$id));
    }
}
