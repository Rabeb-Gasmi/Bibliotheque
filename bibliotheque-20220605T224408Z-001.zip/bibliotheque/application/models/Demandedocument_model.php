<?php

 
class Demandedocument_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
    /*
     * Get demandedocument by id
     */
    function get_demandedocument($id)
    {
        return $this->db->get_where('demandedocument',array('id'=>$id))->row_array();
    }
    
    /*
     * Get all demandedocument count
     */
    function get_all_demandedocument_count()
    {
        $this->db->from('demandedocument');
        return $this->db->count_all_results();
    }
        
    /*
     * Get all demandedocument
     */
    function get_all_demandedocument($params = array())
    {
        $this->db->order_by('id', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        return $this->db->get('demandedocument')->result_array();
    }
        
    /*
     * function to add new demandedocument
     */
    function add_demandedocument($params)
    {
        $this->db->insert('demandedocument',$params);
        return $this->db->insert_id();
    }
    
    /*
     * function to update demandedocument
     */
    function update_demandedocument($id,$params)
    {
        $this->db->where('id',$id);
        return $this->db->update('demandedocument',$params);
    }
    
    /*
     * function to delete demandedocument
     */
    function delete_demandedocument($id)
    {
        return $this->db->delete('demandedocument',array('id'=>$id));
    }
}
