<?php

 
class Commentaire_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
    /*
     * Get commentaire by id
     */
    function get_commentaire($id)
    {
        return $this->db->get_where('commentaire',array('id'=>$id))->row_array();
    }
    
    /*
     * Get all commentaire count
     */
    function get_all_commentaire_count()
    {
        $this->db->from('commentaire');
        return $this->db->count_all_results();
    }
        
    /*
     * Get all commentaire
     */
    function get_all_commentaire($params = array())
    {
        $this->db->order_by('id', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        return $this->db->get('commentaire')->result_array();
    }
        
    /*
     * function to add new commentaire
     */
    function add_commentaire($params)
    {
        $this->db->insert('commentaire',$params);
        return $this->db->insert_id();
    }
    
    /*
     * function to update commentaire
     */
    function update_commentaire($id,$params)
    {
        $this->db->where('id',$id);
        return $this->db->update('commentaire',$params);
    }
    
    /*
     * function to delete commentaire
     */
    function delete_commentaire($id)
    {
        return $this->db->delete('commentaire',array('id'=>$id));
    }
}
