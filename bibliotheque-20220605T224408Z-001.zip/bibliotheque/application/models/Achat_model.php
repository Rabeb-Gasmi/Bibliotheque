<?php

 
class Achat_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
    
    /*
     * Get achat by id
     */
    function get_achat($id)
    {
        return $this->db->get_where('achat',array('id'=>$id))->row_array();
    }
    
    /*
     * Get all achat count
     */
    function get_all_achat_count()
    {
        $this->db->from('achat');
        return $this->db->count_all_results();
    }
        
    /*
     * Get all achat
     */
    function get_all_achat($params = array())
    {
        $this->db->order_by('id', 'desc');
        if(isset($params) && !empty($params))
        {
            $this->db->limit($params['limit'], $params['offset']);
        }
        return $this->db->get('achat')->result_array();
    }
        
    /*
     * function to add new achat
     */
    function add_achat($params)
    {
        $this->db->insert('achat',$params);
        return $this->db->insert_id();
    }
    
    /*
     * function to update achat
     */
    function update_achat($id,$params)
    {
        $this->db->where('id',$id);
        return $this->db->update('achat',$params);
    }
    
    /*
     * function to delete achat
     */
    function delete_achat($id)
    {
        return $this->db->delete('achat',array('id'=>$id));
    }
}
